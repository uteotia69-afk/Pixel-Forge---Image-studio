
"use strict";

const $ = id => document.getElementById(id);

const state = {
  original: null,
  originalURL: null,
  originalName: "image",
  originalType: "image/jpeg",
  originalSize: 0,
  cropper: null,
  crop: null,
  rotation: 0,
  flipH: false,
  flipV: false,
  width: null,
  height: null,
  quality: 85,
  format: "image/jpeg",
  background: "#ffffff",
  targetKB: null,
  history: [],
  historyIndex: -1,
  resultBlob: null,
  resultURL: null,
  rendering: false
};

const imageInput = $("imageInput");
const editorImage = $("editorImage");
const editorArea = $("editorArea");
const dropZone = $("dropZone");

function formatBytes(bytes) {
  if (!bytes && bytes !== 0) return "—";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(2) + " MB";
}

function getDimensions() {
  if (!state.original) return null;
  let w = state.crop ? state.crop.width : state.original.naturalWidth;
  let h = state.crop ? state.crop.height : state.original.naturalHeight;

  if (state.rotation % 180 !== 0) [w, h] = [h, w];

  return {
    width: state.width || Math.max(1, Math.round(w)),
    height: state.height || Math.max(1, Math.round(h))
  };
}

function updateButtons() {
  const hasImage = !!state.original;
  [
    "restoreBtn", "rotateLeft", "rotateRight", "flipH",
    "flipV", "applyCrop", "applyResize", "applyCompress",
    "applyFormat", "downloadBtn"
  ].forEach(id => {
    if ($(id)) $(id).disabled = !hasImage;
  });

  $("undoBtn").disabled = state.historyIndex <= 0;
  $("redoBtn").disabled = state.historyIndex >= state.history.length - 1;
}

function snapshot() {
  return {
    crop: state.crop ? { ...state.crop } : null,
    rotation: state.rotation,
    flipH: state.flipH,
    flipV: state.flipV,
    width: state.width,
    height: state.height,
    quality: state.quality,
    format: state.format,
    background: state.background,
    targetKB: state.targetKB
  };
}

function saveHistory() {
  const snap = snapshot();
  state.history = state.history.slice(0, state.historyIndex + 1);
  state.history.push(snap);

  if (state.history.length > 40) state.history.shift();

  state.historyIndex = state.history.length - 1;
  updateButtons();
}

function restoreSnapshot(snap) {
  Object.assign(state, snap);
  $("resizeW").value = state.width || "";
  $("resizeH").value = state.height || "";
  $("quality").value = state.quality;
  $("qualityValue").textContent = state.quality + "%";
  $("outputFormat").value = state.format;
  $("backgroundColor").value = state.background;

  if (state.cropper && state.crop) {
    state.cropper.setData(state.crop);
  }

  updateButtons();
  renderPreview();
}

function undo() {
  if (state.historyIndex <= 0) return;
  state.historyIndex--;
  restoreSnapshot(state.history[state.historyIndex]);
}

function redo() {
  if (state.historyIndex >= state.history.length - 1) return;
  state.historyIndex++;
  restoreSnapshot(state.history[state.historyIndex]);
}

function loadImage(file) {
  if (!file || !file.type.startsWith("image/")) {
    alert("Please choose a valid image file.");
    return;
  }

  if (file.size > 25 * 1024 * 1024) {
    alert("Image must be smaller than 25 MB.");
    return;
  }

  const url = URL.createObjectURL(file);
  const img = new Image();

  img.onload = () => {
    if (state.originalURL) URL.revokeObjectURL(state.originalURL);
    if (state.resultURL) URL.revokeObjectURL(state.resultURL);

    state.original = img;
    state.originalURL = url;
    state.originalName = file.name.replace(/\.[^.]+$/, "");
    state.originalType = file.type;
    state.originalSize = file.size;

    state.crop = null;
    state.rotation = 0;
    state.flipH = false;
    state.flipV = false;
    state.width = null;
    state.height = null;
    state.quality = 85;
    state.format = "image/jpeg";
    state.background = "#ffffff";
    state.targetKB = null;
    state.history = [];
    state.historyIndex = -1;

    $("outputFormat").value = state.format;
    $("quality").value = 85;
    $("qualityValue").textContent = "85%";
    $("resizeW").value = img.naturalWidth;
    $("resizeH").value = img.naturalHeight;
    $("originalInfo").textContent =
      `${img.naturalWidth} × ${img.naturalHeight} px`;
    $("originalSize").textContent = formatBytes(file.size);
    $("imageStatus").textContent = "Image loaded";
    $("beforeBox").innerHTML = "";
    const beforeImg = document.createElement("img");
    beforeImg.src = url;
    $("beforeBox").appendChild(beforeImg);

    dropZone.classList.add("hidden");
    editorArea.classList.remove("hidden");

    editorImage.src = url;

    editorImage.onload = () => {
      if (state.cropper) state.cropper.destroy();

      state.cropper = new Cropper(editorImage, {
        viewMode: 1,
        dragMode: "crop",
        autoCropArea: 0.85,
        responsive: true,
        background: false,
        movable: true,
        zoomable: true,
        scalable: false,
        rotatable: false,
        crop(event) {
          if (!state.rendering) {
            state.crop = {
              x: event.detail.x,
              y: event.detail.y,
              width: event.detail.width,
              height: event.detail.height
            };
            renderPreview();
          }
        }
      });

      saveHistory();
      renderPreview();
      updateButtons();
    };
  };

  img.onerror = () => {
    URL.revokeObjectURL(url);
    alert("This image could not be opened.");
  };

  img.src = url;
}

imageInput.addEventListener("change", e => {
  loadImage(e.target.files[0]);
});

dropZone.addEventListener("dragover", e => {
  e.preventDefault();
  dropZone.style.borderColor = "#25d6bd";
});

dropZone.addEventListener("dragleave", () => {
  dropZone.style.borderColor = "";
});

dropZone.addEventListener("drop", e => {
  e.preventDefault();
  dropZone.style.borderColor = "";
  loadImage(e.dataTransfer.files[0]);
});

function setCropRatio(value) {
  if (!state.cropper) return;

  if (value === "free") {
    state.cropper.setAspectRatio(NaN);
  } else if (value === "custom") {
    const w = Number($("cropW").value);
    const h = Number($("cropH").value);
    if (w > 0 && h > 0) state.cropper.setAspectRatio(w / h);
  } else {
    state.cropper.setAspectRatio(Number(value));
  }
}

$("cropRatio").addEventListener("change", e => {
  $("customCrop").classList.toggle("hidden", e.target.value !== "custom");
  setCropRatio(e.target.value);
});

$("cropW").addEventListener("input", () => {
  if ($("cropRatio").value === "custom") setCropRatio("custom");
});
$("cropH").addEventListener("input", () => {
  if ($("cropRatio").value === "custom") setCropRatio("custom");
});

$("applyCrop").addEventListener("click", () => {
  if (!state.cropper) return;
  const data = state.cropper.getData(true);
  state.crop = data;
  state.width = null;
  state.height = null;
  $("resizeW").value = Math.round(data.width);
  $("resizeH").value = Math.round(data.height);
  saveHistory();
  renderPreview();
});

$("resizeW").addEventListener("input", () => {
  if (!$("aspectLock").checked || !state.original) return;
  const dims = getDimensions();
  const w = Number($("resizeW").value);
  if (w > 0 && dims) $("resizeH").value =
    Math.max(1, Math.round(w * dims.height / dims.width));
});

$("resizeH").addEventListener("input", () => {
  if (!$("aspectLock").checked || !state.original) return;
  const dims = getDimensions();
  const h = Number($("resizeH").value);
  if (h > 0 && dims) $("resizeW").value =
    Math.max(1, Math.round(h * dims.width / dims.height));
});

$("resizePreset").addEventListener("change", e => {
  if (!e.target.value) return;
  const [w, h] = e.target.value.split(",").map(Number);
  $("resizeW").value = w;
  $("resizeH").value = h;
  $("aspectLock").checked = false;
});

$("applyResize").addEventListener("click", () => {
  const w = Number($("resizeW").value);
  const h = Number($("resizeH").value);

  if (!w || !h || w < 1 || h < 1 || w > 12000 || h > 12000) {
    alert("Enter valid dimensions between 1 and 12000 pixels.");
    return;
  }

  state.width = Math.round(w);
  state.height = Math.round(h);
  saveHistory();
  renderPreview();
});

$("quality").addEventListener("input", e => {
  state.quality = Number(e.target.value);
  $("qualityValue").textContent = state.quality + "%";
  renderPreview();
});

$("targetSize").addEventListener("change", e => {
  $("customSizeBox").classList.toggle("hidden", e.target.value !== "custom");
  state.targetKB = e.target.value === "custom" ? null : Number(e.target.value);
});

$("applyCompress").addEventListener("click", async () => {
  let target = Number($("targetSize").value);

  if ($("targetSize").value === "custom") {
    target = Number($("customSize").value);
  }

  if (!target || target < 1) {
    alert("Enter a valid target size in KB.");
    return;
  }

  state.targetKB = target;
  saveHistory();
  $("applyCompress").disabled = true;
  $("applyCompress").textContent = "Compressing...";

  try {
    await renderPreview();
    alert("Compression settings applied. Check the estimated output size before downloading.");
  } catch (err) {
    alert("Compression failed: " + err.message);
  } finally {
    $("applyCompress").disabled = false;
    $("applyCompress").textContent = "Apply compression";
  }
});

$("outputFormat").addEventListener("change", e => {
  state.format = e.target.value;
  $("backgroundBox").classList.toggle(
    "hidden", state.format !== "image/jpeg"
  );
  renderPreview();
});

$("backgroundColor").addEventListener("change", e => {
  state.background = e.target.value;
  renderPreview();
});

$("applyFormat").addEventListener("click", () => {
  state.format = $("outputFormat").value;
  state.background = $("backgroundColor").value;
  saveHistory();
  renderPreview();
});

function rotate(degrees) {
  if (!state.original) return;
  state.rotation = (state.rotation + degrees + 360) % 360;
  saveHistory();
  renderPreview();
}

$("rotateLeft").addEventListener("click", () => rotate(-90));
$("rotateRight").addEventListener("click", () => rotate(90));

$("flipH").addEventListener("click", () => {
  state.flipH = !state.flipH;
  saveHistory();
  renderPreview();
});

$("flipV").addEventListener("click", () => {
  state.flipV = !state.flipV;
  saveHistory();
  renderPreview();
});

$("undoBtn").addEventListener("click", undo);
$("redoBtn").addEventListener("click", redo);

$("restoreBtn").addEventListener("click", () => {
  if (!state.original) return;
  state.crop = null;
  state.rotation = 0;
  state.flipH = false;
  state.flipV = false;
  state.width = null;
  state.height = null;
  state.quality = 85;
  state.format = "image/jpeg";
  state.targetKB = null;
  $("cropRatio").value = "free";
  $("outputFormat").value = "image/jpeg";
  $("quality").value = 85;
  $("qualityValue").textContent = "85%";
  $("resizeW").value = state.original.naturalWidth;
  $("resizeH").value = state.original.naturalHeight;

  if (state.cropper) {
    state.cropper.reset();
    state.cropper.setAspectRatio(NaN);
  }

  saveHistory();
  renderPreview();
});

function makeCanvas() {
  const original = state.original;
  const crop = state.crop || {
    x: 0, y: 0,
    width: original.naturalWidth,
    height: original.naturalHeight
  };

  let sourceW = Math.max(1, Math.round(crop.width));
  let sourceH = Math.max(1, Math.round(crop.height));

  const swap = state.rotation % 180 !== 0;
  let w = state.width || (swap ? sourceH : sourceW);
  let h = state.height || (swap ? sourceW : sourceH);

  const maxSide = 12000;
  const scale = Math.min(1, maxSide / Math.max(w, h));
  w = Math.max(1, Math.round(w * scale));
  h = Math.max(1, Math.round(h * scale));

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;

  const ctx = canvas.getContext("2d");
  if (state.format === "image/jpeg") {
    ctx.fillStyle = state.background;
    ctx.fillRect(0, 0, w, h);
  }

  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.rotate(state.rotation * Math.PI / 180);
  ctx.scale(state.flipH ? -1 : 1, state.flipV ? -1 : 1);

  const rotatedW = swap ? h : w;
  const rotatedH = swap ? w : h;

  ctx.drawImage(
    original,
    crop.x, crop.y, crop.width, crop.height,
    -rotatedW / 2, -rotatedH / 2,
    rotatedW, rotatedH
  );

  ctx.restore();
  return canvas;
}

function canvasBlob(canvas, type, quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => {
      if (blob) resolve(blob);
      else reject(new Error("Browser could not export this image format."));
    }, type, quality);
  });
}

async function compressCanvas(canvas, type, quality, targetKB) {
  if (!targetKB || type === "image/png") {
    return canvasBlob(canvas, type, quality / 100);
  }

  const targetBytes = targetKB * 1024;
  let currentCanvas = canvas;
  let bestBlob = await canvasBlob(currentCanvas, type, quality / 100);

  if (bestBlob.size <= targetBytes) return bestBlob;

  for (let scale = 0.9; scale >= 0.2; scale -= 0.1) {
    const smaller = document.createElement("canvas");
    smaller.width = Math.max(1, Math.round(canvas.width * scale));
    smaller.height = Math.max(1, Math.round(canvas.height * scale));
    smaller.getContext("2d").drawImage(
      canvas, 0, 0, smaller.width, smaller.height
    );

    for (let q = quality; q >= 20; q -= 10) {
      const blob = await canvasBlob(smaller, type, q / 100);
      if (blob.size < bestBlob.size) bestBlob = blob;
      if (blob.size <= targetBytes) return blob;
    }
    currentCanvas = smaller;
  }

  return bestBlob;
}

async function renderPreview() {
  if (!state.original || state.rendering) return;
  state.rendering = true;

  try {
    const canvas = makeCanvas();
    const blob = await compressCanvas(
      canvas,
      state.format,
      state.quality,
      state.targetKB
    );

    if (state.resultURL) URL.revokeObjectURL(state.resultURL);
    state.resultBlob = blob;
    state.resultURL = URL.createObjectURL(blob);

    const after = $("afterBox");
    after.innerHTML = "";
    const img = document.createElement("img");
    img.src = state.resultURL;
    after.appendChild(img);

    $("finalSize").textContent = formatBytes(blob.size);
    $("finalDimensions").textContent =
      `${canvas.width} × ${canvas.height} px`;
    $("previewInfo").textContent =
      `Preview: ${canvas.width} × ${canvas.height}`;
    $("imageStatus").textContent = "Preview updated";
    $("downloadBtn").disabled = false;
  } catch (error) {
    console.error(error);
    $("imageStatus").textContent = "Preview error";
  } finally {
    state.rendering = false;
  }
}

$("downloadBtn").addEventListener("click", async () => {
  if (!state.original) return;

  $("downloadBtn").disabled = true;
  $("downloadBtn").textContent = "Preparing...";

  try {
    const canvas = makeCanvas();
    const blob = await compressCanvas(
      canvas,
      state.format,
      state.quality,
      state.targetKB
    );

    const extension = {
      "image/jpeg": "jpg",
      "image/png": "png",
      "image/webp": "webp"
    }[state.format] || "jpg";

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${state.originalName}-edited.${extension}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  } catch (error) {
    alert("Download failed: " + error.message);
  } finally {
    $("downloadBtn").disabled = false;
    $("downloadBtn").textContent = "↓ Download final image";
  }
});

// Main navigation
document.querySelectorAll(".nav-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    $(btn.dataset.section).classList.add("active");
  });
});

// Editing tool tabs
document.querySelectorAll(".tool-tab").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tool-tab").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tool-section").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    $("tool-" + btn.dataset.tool).classList.add("active");
  });
});

// PDF merge
let selectedPDFs = [];

$("pdfInput").addEventListener("change", e => {
  selectedPDFs = Array.from(e.target.files || []);
  $("pdfList").innerHTML = "";

  selectedPDFs.forEach((file, index) => {
    const item = document.createElement("div");
    item.className = "pdf-item";

    const name = document.createElement("span");
    name.textContent = `${index + 1}. ${file.name} (${formatBytes(file.size)})`;

    item.appendChild(name);
    $("pdfList").appendChild(item);
  });

  $("mergePdfBtn").disabled = selectedPDFs.length < 2;
  $("pdfStatus").textContent =
    selectedPDFs.length < 2 ? "Choose at least two PDF files." :
    `${selectedPDFs.length} PDF files selected.`;
});

$("mergePdfBtn").addEventListener("click", async () => {
  if (selectedPDFs.length < 2) return;

  if (!window.PDFLib) {
    alert("PDF library could not load. Check your internet connection.");
    return;
  }

  $("mergePdfBtn").disabled = true;
  $("mergePdfBtn").textContent = "Merging...";
  $("pdfStatus").textContent = "Please wait while your PDFs are merged.";

  try {
    const merged = await PDFLib.PDFDocument.create();

    for (const file of selectedPDFs) {
      const bytes = await file.arrayBuffer();
      const pdf = await PDFLib.PDFDocument.load(bytes);
      const pages = await merged.copyPages(pdf, pdf.getPageIndices());
      pages.forEach(page => merged.addPage(page));
    }

    const output = await merged.save();
    const blob = new Blob([output], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "merged-document.pdf";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    $("pdfStatus").textContent = "PDF merged successfully!";
  } catch (error) {
    console.error(error);
    $("pdfStatus").textContent = "Could not merge PDFs. Check that all files are valid PDFs.";
  } finally {
    $("mergePdfBtn").disabled = selectedPDFs.length < 2;
    $("mergePdfBtn").textContent = "Merge & Download PDF";
  }
});

updateButtons();
